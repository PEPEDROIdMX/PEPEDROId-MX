import os
import click
from datetime import timedelta
from werkzeug.security import generate_password_hash
from pepedroid import create_app, db
from pepedroid.models import User, Account, utcnow

app = create_app()

@app.cli.command("create-admin")
@click.option("--username", prompt=True)
@click.option("--password", prompt=True, hide_input=True, confirmation_prompt=True)
def create_admin(username, password):
    if len(password) < 14:
        raise click.ClickException("Usa una contraseña de al menos 14 caracteres.")
    if User.query.filter_by(username=username).first():
        raise click.ClickException("Ese usuario ya existe.")
    user = User(username=username, role="admin")
    user.set_password(password)
    db.session.add(user)
    db.session.commit()
    click.echo("Administrador creado.")

@app.cli.command("expire-accounts")
def expire_accounts():
    now = utcnow()
    changed = Account.query.filter(Account.status == "active",
                                   Account.expires_at.isnot(None),
                                   Account.expires_at <= now).update({"status": "expired"})
    db.session.commit()
    click.echo(f"Cuentas vencidas: {changed}")

if __name__ == "__main__":
    app.run(host=os.environ.get("APP_HOST", "127.0.0.1"),
            port=int(os.environ.get("APP_PORT", "8080")), debug=False)
