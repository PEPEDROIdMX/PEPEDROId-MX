#!/usr/bin/env python3
"""PEPEDROID VPS Manager - interactive terminal interface."""
import os
import socket
import shutil
import subprocess
from datetime import timedelta
from getpass import getpass
from secrets import token_urlsafe
from werkzeug.security import generate_password_hash

from pepedroid import create_app, db
from pepedroid.models import User, Account, License, AuditLog, utcnow

GREEN = "\033[92m"
CYAN = "\033[96m"
YELLOW = "\033[93m"
RED = "\033[91m"
WHITE = "\033[97m"
RESET = "\033[0m"
BOLD = "\033[1m"

def run(cmd):
    try:
        return subprocess.check_output(cmd, stderr=subprocess.DEVNULL, text=True).strip()
    except Exception:
        return "N/D"

def clear():
    os.system("clear")

def pause():
    input(f"\n{YELLOW}Presiona ENTER para continuar...{RESET}")

def header():
    clear()
    mem = shutil.disk_usage("/")
    ram_total = ram_used = "N/D"
    try:
        data = {}
        with open("/proc/meminfo", encoding="utf-8") as f:
            for line in f:
                k, v = line.split(":", 1)
                data[k] = int(v.strip().split()[0])
        ram_total = f"{data['MemTotal']//1024} MiB"
        ram_used = f"{(data['MemTotal']-data.get('MemAvailable', data['MemFree']))//1024} MiB"
    except Exception:
        pass
    ip = run(["bash", "-lc", "hostname -I | awk '{print $1}'"]) or "N/D"
    print(f"{CYAN}{BOLD}")
    print("██████╗ ███████╗██████╗ ███████╗██████╗ ██████╗  ██████╗ ██╗██████╗")
    print("██╔══██╗██╔════╝██╔══██╗██╔══██║██╔══██╗██╔══██╗██╔═══██╗██║██╔══██╗")
    print("██████╔╝█████╗  ██████╔╝███████║██║  ██║██████╔╝██║   ██║██║██║  ██║")
    print("██╔═══╝ ██╔══╝  ██╔═══╝ ╚════██║██║  ██║██╔══██╗██║   ██║██║██║  ██║")
    print("██║     ███████╗██║     ███████║██████╔╝██║  ██║╚██████╔╝██║██████╔╝")
    print("╚═╝     ╚══════╝╚═╝     ╚══════╝╚═════╝ ╚═╝  ╚═╝ ╚═════╝ ╚═╝╚═════╝")
    print(f"{RESET}{WHITE}{BOLD}             VPS MANAGER · PROFESSIONAL EDITION{RESET}")
    print(f"{CYAN}{'━'*66}{RESET}")
    print(f"{WHITE}IP: {GREEN}{ip:<18}{WHITE} RAM: {GREEN}{ram_used}/{ram_total}")
    print(f"{WHITE}DISCO: {GREEN}{mem.used//(1024**3)} GiB / {mem.total//(1024**3)} GiB{RESET}")
    print(f"{CYAN}{'━'*66}{RESET}")

def counts():
    with app.app_context():
        return {
            "SSH": Account.query.filter_by(protocol="ssh").count(),
            "HWID": Account.query.filter_by(protocol="hwid").count(),
            "TOKEN": Account.query.filter_by(protocol="token").count(),
            "VLESS": Account.query.filter_by(protocol="vless").count(),
            "SOCKS": Account.query.filter_by(protocol="socks").count(),
            "HYSTERIA": Account.query.filter_by(protocol="hysteria").count(),
            "ZIVPN": Account.query.filter_by(protocol="zivpn").count(),
            "active": Account.query.filter_by(status="active").count(),
            "resellers": User.query.filter_by(role="reseller", active=True).count(),
        }

def show_menu():
    c = counts()
    print(f"{WHITE}CUENTAS  {GREEN}SSH {c['SSH']}  HWID {c['HWID']}  TOKEN {c['TOKEN']}  VLESS {c['VLESS']}{RESET}")
    print(f"{WHITE}SERVICIOS {GREEN}SOCKS {c['SOCKS']}  HYSTERIA {c['HYSTERIA']}  ZIVPN {c['ZIVPN']}{RESET}")
    print(f"{CYAN}{'─'*66}{RESET}")
    options = [
        "ADMINISTRAR CUENTAS (SSH / HWID / TOKEN)",
        "LISTAR CUENTAS Y ESTADOS",
        "REGISTRAR CUENTA / PERFIL",
        "SUSPENDER CUENTA",
        "LICENCIAS DE 3 HORAS",
        "ADMINISTRAR REVENDEDORES",
        "VENCIMIENTOS AUTOMÁTICOS",
        "ESTADO DEL SERVIDOR",
        "SSL / TLS (ESTADO DE CADDY)",
        "ACTUALIZAR PEPEDROID",
        "SALIR",
    ]
    for i, item in enumerate(options, 1):
        print(f"{YELLOW}[{i:02}] {RED}➜ {GREEN}{item}{RESET}")
    print(f"{CYAN}{'─'*66}{RESET}")

def list_accounts():
    with app.app_context():
        rows = Account.query.order_by(Account.created_at.desc()).limit(40).all()
        if not rows:
            print("No hay cuentas registradas.")
        for a in rows:
            print(f"#{a.id:<4} {a.username:<22} {a.protocol.upper():<10} {a.status:<10} vence={a.expires_at or 'sin vencimiento'} conexiones={a.max_connections}")

def create_account():
    with app.app_context():
        username = input("Identificador: ").strip()
        protocols = ["ssh", "hwid", "token", "vless", "socks", "hysteria", "zivpn"]
        print("Protocolos: " + ", ".join(protocols))
        protocol = input("Protocolo: ").strip().lower()
        if not username or protocol not in protocols or Account.query.filter_by(username=username).first():
            print("Datos inválidos, protocolo no permitido o identificador duplicado.")
            return
        try:
            hours = int(input("Vigencia en horas (0 = sin vencimiento): ").strip() or "3")
            limit = int(input("Conexiones simultáneas (1-100): ").strip() or "1")
            if not 0 <= hours <= 8760 or not 1 <= limit <= 100:
                raise ValueError()
        except ValueError:
            print("Horas o límite fuera de rango.")
            return
        owner = User.query.filter_by(role="admin", active=True).order_by(User.id).first()
        if not owner:
            print("No existe un administrador activo.")
            return
        expires = utcnow() + timedelta(hours=hours) if hours else None
        db.session.add(Account(username=username, protocol=protocol, max_connections=limit,
                               expires_at=expires, owner_id=owner.id))
        db.session.add(AuditLog(actor_id=owner.id, action="cli_account_created", detail=f"{protocol}:{username}"))
        db.session.commit()
        print("Cuenta registrada en la base de datos. El adaptador del protocolo aún debe estar conectado para provisionar el servicio real.")

def suspend_account():
    with app.app_context():
        try:
            account_id = int(input("ID de cuenta: "))
        except ValueError:
            print("ID inválido.")
            return
        a = db.session.get(Account, account_id)
        if not a:
            print("No se encontró esa cuenta.")
            return
        a.status = "suspended"
        db.session.add(AuditLog(action="cli_account_suspended", detail=a.username))
        db.session.commit()
        print(f"Cuenta {a.username} suspendida en el panel.")

def new_license():
    with app.app_context():
        admin = User.query.filter_by(role="admin", active=True).order_by(User.id).first()
        if not admin:
            print("No existe un administrador activo.")
            return
        code = "PEP-" + token_urlsafe(12)
        db.session.add(License(code_hash=generate_password_hash(code), duration_seconds=10800, created_by=admin.id))
        db.session.add(AuditLog(actor_id=admin.id, action="cli_license_created", detail="vigencia=3h"))
        db.session.commit()
        print(f"Guarda esta licencia; no se volverá a mostrar: {GREEN}{code}{RESET}")

def new_reseller():
    with app.app_context():
        username = input("Usuario del revendedor: ").strip()
        password = getpass("Contraseña (mínimo 12 caracteres): ")
        if len(username) < 3 or len(password) < 12 or User.query.filter_by(username=username).first():
            print("Usuario duplicado/inválido o contraseña demasiado corta.")
            return
        u = User(username=username, role="reseller")
        u.set_password(password)
        db.session.add(u)
        db.session.add(AuditLog(action="cli_reseller_created", detail=username))
        db.session.commit()
        print("Revendedor creado.")

def server_status():
    print("SO:", run(["bash", "-lc", ". /etc/os-release && echo \"$PRETTY_NAME\""]))
    print("Uptime:", run(["uptime", "-p"]))
    print("CPU:", run(["bash", "-lc", "nproc"]) + " vCPU")
    print("Memoria:", run(["free", "-h"]))
    print("PEPEDROID:", run(["systemctl", "is-active", "pepedroid"]))
    print("Caddy:", run(["systemctl", "is-active", "caddy"]))

def expire():
    with app.app_context():
        now = utcnow()
        changed = Account.query.filter(Account.status == "active",
                                       Account.expires_at.isnot(None),
                                       Account.expires_at <= now).update({"status": "expired"})
        db.session.commit()
        print(f"Cuentas marcadas como vencidas: {changed}")

def ssl_status():
    print("Servicio Caddy:", run(["systemctl", "is-active", "caddy"]))
    print("Configuración:", run(["caddy", "validate", "--config", "/etc/caddy/Caddyfile"]))

app = create_app()

def main():
    while True:
        header()
        show_menu()
        choice = input(f"{WHITE}➤ Selecciona una opción: {YELLOW}").strip()
        print(RESET)
        if choice == "1":
            list_accounts()
        elif choice == "2":
            list_accounts()
        elif choice == "3":
            create_account()
        elif choice == "4":
            suspend_account()
        elif choice == "5":
            new_license()
        elif choice == "6":
            new_reseller()
        elif choice == "7":
            expire()
        elif choice == "8":
            server_status()
        elif choice == "9":
            ssl_status()
        elif choice == "10":
            print("Actualización: instala una versión verificada desde el repositorio oficial.")
        elif choice == "11":
            print("Para desinstalar, utiliza el procedimiento documentado; no se borra automáticamente la base de datos.")
            break
        else:
            print("Opción no válida.")
        pause()

if __name__ == "__main__":
    main()
