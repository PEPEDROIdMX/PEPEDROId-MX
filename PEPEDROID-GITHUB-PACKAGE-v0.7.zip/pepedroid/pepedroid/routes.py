from datetime import timedelta
from secrets import token_urlsafe
from flask import Blueprint, render_template, request, redirect, url_for, flash, abort
from flask_login import login_user, logout_user, login_required, current_user
from werkzeug.security import generate_password_hash
from . import db
from .models import User, Account, License, AuditLog, utcnow
from .security import roles_required

main = Blueprint("main", __name__)

def log(action, detail=""):
    db.session.add(AuditLog(actor_id=current_user.id if current_user.is_authenticated else None,
                            action=action, detail=detail[:500]))

@main.route("/")
@login_required
def dashboard():
    if not current_user.active:
        logout_user()
        return redirect(url_for("main.login"))
    q = Account.query
    if current_user.role != "admin":
        q = q.filter_by(owner_id=current_user.id)
    accounts = q.order_by(Account.created_at.desc()).limit(50).all()
    return render_template("dashboard.html", accounts=accounts,
        total=q.count(), active=q.filter_by(status="active").count(),
        expired=q.filter_by(status="expired").count())

@main.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        user = User.query.filter_by(username=request.form.get("username", "").strip()).first()
        if user and user.active and user.check_password(request.form.get("password", "")):
            login_user(user)
            return redirect(url_for("main.dashboard"))
        flash("Credenciales incorrectas o cuenta deshabilitada.", "error")
    return render_template("login.html")

@main.route("/logout", methods=["POST"])
@login_required
def logout():
    logout_user()
    return redirect(url_for("main.login"))

@main.route("/accounts/new", methods=["GET", "POST"])
@login_required
def new_account():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        protocol = request.form.get("protocol", "")
        try:
            hours = int(request.form.get("hours", "0"))
            limit = int(request.form.get("max_connections", "1"))
        except ValueError:
            flash("Horas y conexiones deben ser números.", "error")
            return redirect(url_for("main.new_account"))
        allowed = {"ssh", "hwid", "token", "vless", "socks", "hysteria", "zivpn"}
        if not username or len(username) > 64 or protocol not in allowed or not (1 <= limit <= 100) or not (0 <= hours <= 8760):
            flash("Revisa los datos. Horas: 0–8760; conexiones: 1–100.", "error")
            return redirect(url_for("main.new_account"))
        if Account.query.filter_by(username=username).first():
            flash("Ese identificador ya existe.", "error")
            return redirect(url_for("main.new_account"))
        expires = utcnow() + timedelta(hours=hours) if hours else None
        account = Account(username=username, protocol=protocol, max_connections=limit,
                          expires_at=expires, owner_id=current_user.id)
        db.session.add(account)
        log("account_created", f"{protocol}:{username}")
        db.session.commit()
        flash("Cuenta registrada en PEPEDROID. La integración con el servicio se configura por separado.", "success")
        return redirect(url_for("main.dashboard"))
    return render_template("new_account.html")

@main.route("/accounts/<int:account_id>/suspend", methods=["POST"])
@login_required
def suspend_account(account_id):
    account = Account.query.get_or_404(account_id)
    if current_user.role != "admin" and account.owner_id != current_user.id:
        abort(403)
    account.status = "suspended"
    log("account_suspended", account.username)
    db.session.commit()
    flash("Cuenta suspendida en el panel.", "success")
    return redirect(url_for("main.dashboard"))

@main.route("/licenses/new", methods=["POST"])
@roles_required("admin", "reseller")
def new_license():
    code = "PEP-" + token_urlsafe(12)
    license_obj = License(code_hash=generate_password_hash(code),
                          duration_seconds=10800, created_by=current_user.id)
    db.session.add(license_obj)
    log("license_created", "vigencia=3h")
    db.session.commit()
    flash(f"Licencia creada (guárdala ahora; no se volverá a mostrar): {code}", "success")
    return redirect(url_for("main.dashboard"))

@main.route("/resellers/new", methods=["GET", "POST"])
@roles_required("admin")
def new_reseller():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        if len(username) < 3 or len(password) < 12 or User.query.filter_by(username=username).first():
            flash("Usuario duplicado/inválido o contraseña menor a 12 caracteres.", "error")
            return redirect(url_for("main.new_reseller"))
        user = User(username=username, role="reseller")
        user.set_password(password)
        db.session.add(user)
        log("reseller_created", username)
        db.session.commit()
        flash("Revendedor creado.", "success")
        return redirect(url_for("main.dashboard"))
    return render_template("new_reseller.html")
