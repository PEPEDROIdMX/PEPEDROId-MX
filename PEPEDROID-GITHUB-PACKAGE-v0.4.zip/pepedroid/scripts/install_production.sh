#!/usr/bin/env bash
set -euo pipefail

if [[ "${EUID}" -ne 0 ]]; then
  echo "Ejecuta: sudo ./scripts/install_production.sh"
  exit 1
fi

SOURCE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
APP_DIR="/opt/pepedroid"
ENV_DIR="/etc/pepedroid"

if ! id pepedroid >/dev/null 2>&1; then
  useradd --system --home-dir "$APP_DIR" --shell /usr/sbin/nologin pepedroid
fi

install -d -o root -g pepedroid -m 0750 "$APP_DIR"
install -d -o root -g root -m 0750 "$ENV_DIR"

# Copy application files while keeping deployment scripts owned by root.
cp -a "$SOURCE_DIR/." "$APP_DIR/"
chown -R root:pepedroid "$APP_DIR"
chmod -R u=rwX,g=rX,o= "$APP_DIR"
install -d -o pepedroid -g pepedroid -m 0750 "$APP_DIR/instance"

apt-get update
DEBIAN_FRONTEND=noninteractive apt-get install -y python3 python3-venv python3-pip

python3 -m venv "$APP_DIR/venv"
"$APP_DIR/venv/bin/pip" install --upgrade pip
"$APP_DIR/venv/bin/pip" install -r "$APP_DIR/requirements.txt"

if [[ ! -f "$ENV_DIR/pepedroid.env" ]]; then
  SECRET="$(openssl rand -hex 32)"
  cat > "$ENV_DIR/pepedroid.env" <<EOF
FLASK_SECRET_KEY=${SECRET}
DATABASE_URL=sqlite:////opt/pepedroid/instance/pepedroid.db
COOKIE_SECURE=1
APP_HOST=127.0.0.1
APP_PORT=8080
EOF
  chmod 0640 "$ENV_DIR/pepedroid.env"
  chown root:pepedroid "$ENV_DIR/pepedroid.env"
fi

install -m 0644 "$APP_DIR/deployment/pepedroid.service" /etc/systemd/system/pepedroid.service
systemctl daemon-reload
systemctl enable pepedroid
systemctl restart pepedroid

echo
echo "PEPEDROID app service installed."
echo "Check: systemctl status pepedroid --no-pager"
echo "Next: create admin with:"
echo "  cd /opt/pepedroid"
echo "  sudo -u pepedroid /opt/pepedroid/venv/bin/flask --app manage.py create-admin"
echo
echo "Do not expose port 8080 publicly. Caddy should proxy to 127.0.0.1:8080."
