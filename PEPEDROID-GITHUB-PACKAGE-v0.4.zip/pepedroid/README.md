# PEPEDROID VPS — Starter 0.1

Panel inicial de administración VPS con interfaz web y CLI. Diseñado para Ubuntu/Debian y servidores pequeños.

## Incluye en esta primera versión
- Inicio de sesión con hash de contraseña y protección CSRF.
- Roles iniciales `admin` y `reseller`.
- Registro de cuentas por protocolo (SSH, HWID, TOKEN, VLESS, SOCKS, Hysteria, ZIVPN).
- Fecha de vencimiento, límite configurado de conexiones y suspensión desde el panel.
- Generación de códigos de licencia de 3 horas (en esta versión se crean; falta flujo de canje/activación).
- Comando CLI para crear administrador y expirar cuentas.
- Registro de auditoría básico.

## Importante: alcance real del starter
Este es un MVP de gestión: todavía **no instala ni modifica** OpenSSH, Xray, SOCKS, Hysteria o ZIVPN, no verifica conexiones en vivo, y no aplica límites de conexiones en los demonios. Los adaptadores de servicios deben desarrollarse y probarse por separado antes de habilitarlos. No se debe presentar el estado de la base de datos como estado real de una conexión.

## Instalación de desarrollo
```bash
sudo apt update
sudo apt install -y python3 python3-venv python3-pip
unzip pepedroid-starter.zip
cd pepedroid
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
```
Edita `.env` y define un `FLASK_SECRET_KEY` aleatorio. No uses la clave de ejemplo.

Crea el administrador:
```bash
set -a; source .env; set +a
flask --app manage.py create-admin
```
Inicia en localhost para pruebas:
```bash
flask --app manage.py run --host 127.0.0.1 --port 8080
```
Abre un túnel SSH desde tu computadora/teléfono o configura un proxy HTTPS inverso. No expongas el servidor Flask de desarrollo directamente a Internet.

## Vencimientos automáticos
Prueba manual:
```bash
flask --app manage.py expire-accounts
```
Después de validar, programa el comando con systemd timer o cron cada minuto. Ejemplo cron:
```cron
* * * * * cd /ruta/pepedroid && /ruta/pepedroid/.venv/bin/flask --app manage.py expire-accounts
```

## Siguiente fase recomendada
1. Migraciones de base de datos y pruebas automatizadas.
2. Canje de licencia con código de un solo uso y activación al primer uso.
3. Cuotas de revendedor y delegación segura de cuentas.
4. Adaptadores idempotentes para servicios instalados por el administrador.
5. Medición real de conexiones y aplicación de límites en cada servicio.
6. Despliegue de producción con Gunicorn, Nginx/Caddy, HTTPS, firewall y copias de seguridad.

## Seguridad
- Ejecuta la aplicación web como usuario sin privilegios.
- No ejecutes comandos de shell construidos a partir de entradas del usuario.
- No guardes contraseñas de servicios en texto plano.
- Restringe el acceso administrativo y usa HTTPS.
- Mantén el sistema operativo y dependencias actualizados.


## TLS / SSL (PEPEDROID 0.2 — módulo de despliegue)
- Se añade plantilla `deployment/Caddyfile.example`.
- Se añade `scripts/configure_caddy.sh` para configurar Caddy con un dominio y correo reales.
- Caddy termina HTTPS y reenvía al backend Flask en `127.0.0.1:8080`.
- Guía `deployment/TLS_SERVICES.md` explica la diferencia entre HTTPS del panel y TLS propio de cada protocolo.

**Actualmente no hay dominio:** no es posible emitir todavía un certificado público de confianza para el panel. Para producción, registra un dominio/subdominio, apunta su DNS a la IP del VPS y permite TCP 80/443. Un certificado autofirmado sirve solo para pruebas y genera advertencias.

**TLS de SSH/VLESS/SOCKS/Hysteria/ZIVPN no queda activado por el certificado del panel.** Cada protocolo requiere un adaptador y configuración específica; SSH usa su propio cifrado y Hysteria usa TLS sobre QUIC. No abras puertos de servicios hasta configurar y probar cada adaptador.


## Despliegue de producción inicial
1. Sube el ZIP a Ubuntu y descomprímelo.
2. Entra en la carpeta `pepedroid` y ejecuta `sudo ./scripts/install_production.sh`.
3. Crea el administrador con el comando que imprime el instalador.
4. Instala Caddy desde el repositorio oficial de Caddy y configura `/etc/caddy/Caddyfile` con `deployment/Caddyfile.example`.
5. Asegura que DNS A del dominio apunte a la IP del VPS y que TCP 80/443 estén permitidos.
6. Verifica `systemctl status pepedroid caddy`.

El servicio Gunicorn escucha solo en localhost. El puerto 8080 no debe abrirse en el firewall.
