# TLS para PEPEDROID

## 1. HTTPS del panel
La configuración recomendada es Caddy como proxy inverso:
- Flask/Gunicorn escucha solamente en `127.0.0.1:8080`.
- Caddy escucha públicamente en TCP 80 y 443.
- Caddy solicita y renueva el certificado público automáticamente.
- El panel no debe exponerse directamente mediante el servidor de desarrollo Flask.

## 2. No hay dominio todavía
Let's Encrypt normalmente necesita un nombre de dominio público que resuelva hacia la IP del VPS y que pueda validarse. Sin dominio:
- No se puede ofrecer HTTPS público con un certificado de confianza para un nombre propio.
- Para pruebas privadas se puede usar un certificado autofirmado, pero los navegadores mostrarán una advertencia y no debe utilizarse como solución pública.
- Se puede comprar o registrar un dominio/subdominio y crear un registro A (y AAAA solo si IPv6 está configurado) apuntando al VPS.

No habilites HSTS hasta que HTTPS funcione correctamente para el dominio definitivo.

## 3. TLS de servicios
SSH, VLESS, SOCKS, Hysteria y ZIVPN no comparten una configuración SSL universal:
- SSH utiliza su propio protocolo y claves de host; no se convierte en TLS por añadir un certificado web.
- VLESS puede utilizar TLS/REALITY según el transporte y el servidor Xray configurado.
- SOCKS necesita un transporte TLS adicional si se requiere cifrado TLS; SOCKS puro no equivale a HTTPS.
- Hysteria utiliza QUIC con TLS integrado y necesita su propio certificado/clave y configuración.
- ZIVPN depende de la implementación y versión concreta; se debe validar su soporte TLS antes de generar configuración.

Los adaptadores de cada servicio deben leer certificados desde rutas protegidas, validar permisos y recargar solo el servicio correspondiente. Nunca reutilizar el certificado del panel automáticamente para todos los protocolos sin verificar compatibilidad.

## 4. Puertos y seguridad
- TCP 80: validación HTTP y redirección HTTPS.
- TCP 443: HTTPS del panel (y solo servicios que se configuren expresamente para ese puerto).
- No abrir puertos adicionales sin definir qué servicio los necesita.
- Mantener la clave privada legible únicamente por root y el grupo de servicio requerido.
- No registrar claves privadas, tokens ni contraseñas.
- Respaldar configuración, no distribuir claves privadas entre revendedores.

## 5. Configurador
`sudo ./scripts/configure_caddy.sh` configura Caddy después de instalarlo y de apuntar el DNS al VPS. El script no instala Caddy ni abre el firewall automáticamente.
