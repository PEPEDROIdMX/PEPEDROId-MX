#!/usr/bin/env bash
set -euo pipefail

if [[ "${EUID}" -ne 0 ]]; then
  echo "Ejecuta este configurador con sudo."
  exit 1
fi

read -r -p "Dominio (ej. panel.midominio.com): " DOMAIN
read -r -p "Correo para avisos de Let's Encrypt: " EMAIL

if [[ ! "$DOMAIN" =~ ^([A-Za-z0-9-]+\.)+[A-Za-z]{2,}$ ]]; then
  echo "Dominio no válido."
  exit 1
fi
if [[ ! "$EMAIL" =~ ^[^@[:space:]]+@[^@[:space:]]+\.[^@[:space:]]+$ ]]; then
  echo "Correo no válido."
  exit 1
fi

if ! command -v caddy >/dev/null 2>&1; then
  echo "Caddy no está instalado."
  echo "Instálalo siguiendo la documentación oficial: https://caddyserver.com/docs/install"
  exit 1
fi

install -d -m 0755 /etc/caddy
cat > /etc/caddy/Caddyfile <<EOF
{
    email ${EMAIL}
}

${DOMAIN} {
    encode zstd gzip
    reverse_proxy 127.0.0.1:8080
    header {
        Strict-Transport-Security "max-age=31536000; includeSubDomains"
        X-Content-Type-Options "nosniff"
        Referrer-Policy "strict-origin-when-cross-origin"
        -Server
    }
}
EOF

caddy validate --config /etc/caddy/Caddyfile
systemctl enable caddy
systemctl reload caddy || systemctl restart caddy
echo "Configuración guardada. Asegúrate de que DNS apunte a este VPS y TCP 80/443 estén accesibles."
